2021-11-16-International Journal of Geomechanics
